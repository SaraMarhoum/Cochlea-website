<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

/*! ===================================
 *  Author: Nazarkin Roman, WPHunters
 *  -----------------------------------
 *  Email(support):
 * 	bbdesign_sp@yahoo.com
 *  ===================================
 */



/**
 * Register a portfolio post type.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */

$args = array(
	'label'       => __( 'Portfolio', 'jo-theme-cpt' ),
	'labels'      => array(
		'add_new_item' => __( 'Add new portfolio item', 'jo-theme-cpt' ),
		'add_new'      => __( 'Add new', 'jo-theme-cpt' )
	),
	'public'      => true,
	'has_archive' => false,
	'menu_icon'   => 'dashicons-schedule',
	'rewrite' => array(
		'slug' => 'work'
	),
	'supports'    => array(
		'title',
		'editor',
		'custom-fields',
		'revisions',
		'page-attributes',
		'thumbnail'
	)
);

// register post type
register_post_type( 'jo-portfolio', $args );

// portfolio tags
register_taxonomy(
	'jo-portfolio-tag',
	'jo-portfolio',
	array(
		'hierarchical'  => false,
		'public'        => false,
		'show_ui'       => true,
		'label'         => __( 'Portfolio Tags', 'jo-theme-cpt' ),
		'singular_name' => __( 'Portfolio Tag', 'jo-theme-cpt' ),
	)
);



/**
 * Register a testimonials post type.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */

$args = array(
	'label'     => __( 'Testimonials', 'jo-theme-cpt' ),
	'labels'    => array(
		'add_new_item' => __( 'Add new testimonial', 'jo-theme-cpt' ),
		'add_new'      => __( 'Add new', 'jo-theme-cpt' )
	),
	'public'    => false,
	'show_ui'   => true,
	'menu_icon' => 'dashicons-format-chat',
	'supports'  => array(
		'title',
		'editor',
		'custom-fields',
		'revisions',
		'page-attributes'
	)
);

register_post_type( 'jo-testimonials', $args );
