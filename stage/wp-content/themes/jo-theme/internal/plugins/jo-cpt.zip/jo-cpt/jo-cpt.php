<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }
/*
Plugin Name: JO Theme CPTs
Plugin URI: http://wphunters.com/
Description: "JO" custom post type's for only "JO" wp theme.
Version: 1.0
Author: WPHunters
Author URI: http://wphunters.com
License: GPLv2
*/

// load textdomain
add_action( 'plugins_loaded', 'wph_cpt_load_textdomain' );
function wph_cpt_load_textdomain() {
	load_plugin_textdomain( 'jo-theme-cpt', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
}

// init CPTs
add_action( 'init', 'wph_init_cpts', 9 );
function wph_init_cpts() {
	$cptFile = plugin_dir_path( __FILE__ ) . '/init-cpts.php';
	if ( ! file_exists( $cptFile ) ) {
		return;
	}

	include $cptFile;
}
